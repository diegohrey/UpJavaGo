package com.upjavago.proyecto_ciclo03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCiclo03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
